IFT3913-A-A22-TP
Hugo Carrier: 20197563
Maggie Robert: 20182443

Lien au répertoire Github: https://github.com/3Pi1416/IFT3913-A-A22-TP2

###########################
commentDensity.py
###########################
Entrée: sys.argv avec le path vers le répertoire à mesurer
Sortie: imprime dans le console les données collectées et une image d'un graphe dans le même repértoir que le programme

###########################
csec.py
###########################
Entrée: sys.argv avec le path vers le répertoire à mesurer
Sortie: imprime dans le console les données collectées

###########################
gitStat.py
###########################
Entrée: sys.argv avec le path vers le répertoire à mesurer
Sortie: imprime dans le console les données collectées

###########################
fileSize.py
###########################
Entrée: sys.argv avec le path vers le répertoire à mesurer
Sortie: imprime dans le console les données collectées

###########################
ratioCodeTestPhysicalSize.py
###########################
Entrée: sys.argv: le path vers le répertoire main, le path vers le répertoire test
Sortie: imprime dans le console les données collectées

###########################
ratioTestJavaFile.py
###########################
Entrée: sys.argv: le path vers le répertoire main, le path vers le répertoire test
Sortie: imprime dans le console les données collectées

Les données collectées pour chaque métrique peut être trouver dans output.txt